# Team C2 Hardware Engineering Final Report - Final Overleaf Package

## Compile in Overleaf
1. Upload the complete ZIP as a new Overleaf project.
2. Set `main.tex` as the main document.
3. Select **pdfLaTeX** as the compiler.
4. Use **Recompile from scratch** once. Overleaf will run BibTeX automatically.

## Package contents
- `main.tex` - final IEEE conference-format report.
- `main.pdf` - compiled final report.
- `references.bib` - IEEE, AMD/Vivado, Digilent, Altium, and textbook references.
- `IEEEtran.cls` - IEEE conference class.
- `figures/` - all project figures, each used individually in the report.
- `source_evidence/` - VHDL sources, testbenches, constraints, bitstream, BOM, schematic/layout PDFs, and Gerber/drill files.

## Report decisions
- Every supplied project image is inserted as an individual figure; no collages are used.
- The final Team C2 Nexys A7 photograph is the only physical realization image.
- Non-team hardware realization images are excluded.
- Detailed Vivado post-implementation records are excluded from the report.
- Scenario 3 (Emergency Override) is stored in the supplied file `Scenario_8.jpeg` and is captioned correctly in the report.
- Quantitative utilization/timing values are not invented because the package does not include exported sign-off reports.
