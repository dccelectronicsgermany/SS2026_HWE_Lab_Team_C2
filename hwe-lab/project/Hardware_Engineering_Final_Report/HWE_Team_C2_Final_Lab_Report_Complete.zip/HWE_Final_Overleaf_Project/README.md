# Team C2 Hardware Engineering Final Report

## Overleaf compilation
1. Upload this complete folder or the ZIP file to Overleaf.
2. Set `main.tex` as the main document.
3. Use pdfLaTeX.
4. Compile twice; BibTeX is invoked automatically by Overleaf when references are present.

## Main files
- `main.tex`: complete IEEE conference-format report.
- `references.bib`: AMD/Vivado, Artix-7, Digilent, IEEE VHDL, Altium, and textbook references.
- `figures/`: report-ready project figures.
- `source_evidence/`: VHDL, testbenches, constraints, bitstream, BOM, schematics, layout, and Gerber evidence.

## Evidence limitations stated in the report
The archive did not contain exported Vivado utilization or timing reports. Therefore, the paper does not invent numerical timing/resource results. Add these reports later if available.
